<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2024 Brought To You By <a href="https://pk.com.np/">Pranita Koirala</a></strong>
</footer>