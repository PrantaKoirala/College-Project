<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>


<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <div class="content-wrapper">
      <div class="container">
   
<center>
  <h1><u>Contact Bhai Fancy Store at:</u></h1><br>
  <p>
    
      <b>Contact Number:</b>&nbsp;+977 9813538748<br><br>
      <b>Address(physical):</b>&nbsp;Tindhara, Banepa<br><br>
      <b>For any queries:</b>&nbsp;queries_bhaifancy@gmail.com<br><br>
      
     </p>
    
</div>
</center>
 
</div>
</div>
  
<?php include 'includes/footer.php'; ?>

  </div>

<?php include 'includes/scripts.php'; ?>
</body>
</html>