<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2024 Brought to You By <a href="http://pranitakoirala.np" target="_blank">Pranita Koirala</a></strong>
    </div>
</footer>